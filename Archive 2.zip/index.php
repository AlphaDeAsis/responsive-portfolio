<?php include_once("index.html"); ?>
<?php include_once("portfolio.html"); ?>
<?php include_once("contacts.html"); ?>